# StockMixer mini-project report

**Title:** Reproduction and Extension of StockMixer for Stock Price Forecasting  
**Author:** Kavin Karthik Yuvaraj, 24011101055  
**Affiliation:** Shiv Nadar University Chennai  
**Email:** kavinkarthik24110077@snuchennai.edu.in

The accompanying PDF contains exactly six pages, including references, in the supplied IEEEtran conference format. It contains all required report sections, three results/timing/diagnostic tables, four vector figures, and eight references. The abstract includes the project repository: https://github.com/artemiskavin/Stock-Mixer.

## Edit and compile

Open `main.tex` as the main document. Supporting text is in `sections/`; bibliography entries are in `references.tex`; all figures are supplied as vector PDFs in `figures/`.

Compile with a normal TeX installation, for example:

```text
latexmk -xelatex main.tex
```

Alternatively use `tectonic main.tex`, or upload the complete source package to Overleaf and choose XeLaTeX. IEEEtran and the standard packages listed in the preamble must be available. The supplied PDF was compiled with Tectonic 0.17.0 and visually inspected on all six pages. Different TeX distributions can cause small layout changes; check the page count after edits or recompilation.

## Evidence and scope

Reported values were taken from completed experiment artifacts. Modified-configuration results are arithmetic means and sample standard deviations of the retained lowest-validation-loss selections. Released-trainer rows retain the previously recorded rounded metrics; those console records do not provide exact recoverable checkpoints. No new training, evaluation, checkpoint reselection, or scientific-source modification was performed for this report.

The package is a local report source distribution. It does not contain datasets, checkpoints, credentials, compiler executables, private audit files, or environment caches. The repository URL is linked; no GitHub push was performed. Prior scientific artifacts and earlier report versions were preserved.
